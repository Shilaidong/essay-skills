# Study Abroad Strategy Report Designer

A reusable AI Agent Skill for generating premium study abroad admission strategy reports.

## Usage

Input:
- Student files
- Consultation notes
- Academic records
- Activity lists

Output:
- HTML report
- PDF report
- Structured JSON

Designed for:
- OpenCode
- Claude Code
- GPT Agent
- Other coding agents
