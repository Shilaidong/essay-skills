# Study Abroad Strategy Report Designer Skill

## Overview

Generate premium study abroad admission strategy reports from student materials.

The output should be a consulting-grade document, not an AI summary.

Workflow:

Input Materials
→ Student Analysis
→ Admission Strategy
→ HTML Report
→ PDF Export

Target quality:
- McKinsey style consulting report
- BCG strategy document
- Stanford education advisory report

---

## Main Goals

The report must answer:

1. Who is this student?
2. What makes the student distinctive?
3. What are current strengths and weaknesses?
4. What is the optimal application positioning?
5. Which activities should be strengthened?
6. Which activities should be reduced?
7. What is the execution roadmap?

---

## Required Sections

1. Cover Page

2. Executive Summary

3. Student Profile

4. Academic Analysis

5. Activity Portfolio Analysis

6. Application Identity / Positioning

7. Major Direction Analysis

8. Parent Information Analysis

9. Consultant Recommendations

10. Timeline Roadmap

11. Risk Analysis

12. Glossary

---

## Activity Analysis Format

Every activity must include:

- Current Status
- Admission Value
- Strategic Role
- Future Development Plan

Do not create simple activity lists.

---

## Positioning Logic

Define:

"Who is this student in the eyes of admission officers?"

Avoid generic descriptions.

Examples:

- Research-oriented student
- Technology and social impact student
- Creative engineering student
- Entrepreneurship student

---

## Major Explanation

For every major:

Explain:

- What is this field?
- What do students study?
- Career pathways
- Why suitable for this student
- Related universities

---

## HTML First Design

The report must be generated as:

HTML + CSS → PDF

Do not rely on Word formatting.

Recommended:

Chromium / Puppeteer rendering.

---

## Design System

Style:

Professional
Modern
Editorial
Minimal

Inspired by:

- McKinsey reports
- BCG publications
- Stanford research documents

Avoid:

- PPT style
- Excessive colors
- Decorative icons
- SaaS dashboard style

---

## Components

Use reusable HTML components:

- Cover page
- Strategic cards
- Highlight boxes
- Timeline
- Comparison tables
- Activity matrix
- Summary blocks

---

## PDF Requirements

A4 format.

Need:

- Print CSS
- Page breaks
- Header/footer
- Page numbers
- No overflow
- Stable tables

---

## Quality Checklist

Content:

✓ Complete student information
✓ Strategic recommendations
✓ Activity interpretation
✓ Future roadmap
✓ Professional explanations

Design:

✓ Premium cover
✓ Consistent typography
✓ Clear hierarchy
✓ Good whitespace
✓ PDF-ready

---

Final principle:

The output should feel like a high-value education consulting deliverable.
